var nameArray = ["Vikram", "Sumithra", "Chris", "Jerrine"]

class Person {
    
    var name = nameArray[Int.random(in: 0...nameArray.count-1)]
    
    func introduceMyself() {
        print("Hi, name is \(name)")
    }
    
}
class Chef: Person {
    override func introduceMyself() {
        print("Hi, my name is \(super.name).")
        print("I'm a chef.")
    }
}
class Poet: Person {
    override func introduceMyself() {
        print("Hi, my name is \(super.name).")
        print("I'm a Poet.")
    }
}
class Astronaut: Person {
    override func introduceMyself() {
        print("Hi, my name is \(super.name).")
        print("I'm an Astronaut.")
    }
}

var counter = 0
while counter < 10 {
    var classArray = [Chef(), Poet(), Astronaut()]
    var c = classArray[Int.random(in: 0...classArray.count-1)]
    c.introduceMyself()
    counter += 1
}

