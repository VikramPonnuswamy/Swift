//
//  ContentView.swift
//  Loops
//
//  Created by Vikram Ponnuswamy on 14/04/2023.
//

import SwiftUI

struct ContentView: View {
    //Array that stores number 1-10
    let number = [1,2,3,4,5,6,7,8,9,10]
    //Array that stores the randomly chosen value in list form on the screen
    @State var addToList = [Int]()
    //Message output
    @State var message = "Press Add Integer"
    
    var body: some View {
        //VStack is use to align the list, message and buttons
        VStack {
            List (addToList, id: \.self) {arrayElement in
                
                Text(String(arrayElement))
                
            }
            Text(message)
            HStack {
                VStack {
                    Button {
                        addInteger()
                        
                    } label: {
                        HStack{
                            Text("Add Integer")
                            Image(systemName: "plus.app")
                        }
                        .padding(.all)
                        .background(.blue)
                        .foregroundColor(.white)
                        
                        }
                    Text("")

                }
                VStack {
                    Button {
                        increaseInteger()
                    } label: {
                        HStack{
                            Text("Increase Integer")
                            Image(systemName: "arrow.up")
                        }
                        .padding(.all)
                        .background(.blue)
                        .foregroundColor(.white)
                    }
                    Text ("")
                }
                VStack {
                    Button {
                        clearList()
                    } label: {
                        HStack{
                            Text("Clear List")
                            Image(systemName: "minus.square")
                        }
                        .padding(.all)
                        .background(.blue)
                        .foregroundColor(.white)
                    }
                    Text("")
                }
            }//closes the Hstack of the buttons
        }//closes the top level Vstack
    }
    
    func addInteger() {
            
        if addToList.contains(7) {
            message = ("Number 7 has been reached")
            return
        }
        else {
            let randIndex = Int.random(in: 0...number.count-1)
            addToList.append(number[randIndex])
            
        }
            
      
        
    }//end of addInteger() func
    
    func increaseInteger() {
        for plusOne in addToList {
            addToList.append(plusOne+1)
            message = "Increment Successful"
        }
        
        
        
    }//end of increaseInteger() func
    
    func clearList() {
            addToList.removeAll()
        message = "List cleared"
        
    }
}//end of clearList() func

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
