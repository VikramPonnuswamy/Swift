//
//  MVVMApp.swift
//  MVVM
//
//  Created by Vikram Ponnuswamy on 15/04/2023.
//

import SwiftUI

@main
struct MVVMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
