//
//  modelMVVM.swift
//  MVVM
//
//  Created by Vikram Ponnuswamy on 15/04/2023.
//

import Foundation

class Pizza: Identifiable {
    
    var id =  UUID()
    var name = ""
    var topping1 = ""
    var topping2 = ""
    var topping3 = ""
}
