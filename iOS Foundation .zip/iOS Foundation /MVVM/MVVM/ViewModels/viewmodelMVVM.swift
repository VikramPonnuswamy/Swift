//
//  viewmodelMVVM.swift
//  MVVM
//
//  Created by Vikram Ponnuswamy on 15/04/2023.
//

import Foundation

class PizzaModel: ObservableObject {
    
    @Published var recipes = [Pizza]()
    
    init() {
       
        let firstPizza = Pizza()
        firstPizza.name = "Flaming Torch"
        firstPizza.topping1 = "Jalepenos"
        firstPizza.topping2 = "Tandoori Chicken"
        firstPizza.topping3 = "Green Chillis"
        recipes.append(firstPizza)
        
        let secondPizza = Pizza()
        secondPizza.name = "Margherita"
        secondPizza.topping1 = "Tomato Sauce"
        secondPizza.topping2 = "Mozerrella Cheese"
        secondPizza.topping3 = "Basil"
        recipes.append(secondPizza)
        
        let thirdPizza = Pizza()
        thirdPizza.name = "Chicken Masti"
        thirdPizza.topping1 = "Chennai Chicken"
        thirdPizza.topping2 = "Tandoori Chicken"
        thirdPizza.topping3 = "Green Chicken"
        recipes.append(thirdPizza)
        
        
    }
    
    func addPineapple() {
        
         Pizza().topping1 = "Pineapple"
        
    }
    
}
