//
//  ContentView.swift
//  MVVM
//
//  Created by Vikram Ponnuswamy on 15/04/2023.
//

import SwiftUI

struct ContentView: View {
   
   @ObservedObject var model = PizzaModel()
    
    var body: some View {
        
        VStack {
            List(model.recipes) { r in
                
                VStack {
                    Text(r.name)
                        .font(.largeTitle)
                    HStack{
                        Spacer()
                        Text(r.topping1)
                            .frame(width: 100, height: 50)
                        Spacer()
                        Text(r.topping2)
                            .frame(width: 100,height: 50)
                        Spacer()
                        Text(r.topping3)
                            .frame(width: 100, height: 50)
                        Spacer()
                        
                    }
                }
                
            }
            Button("Add Pineapple", action: model.addPineapple)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
