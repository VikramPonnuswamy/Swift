//
//  ContentView.swift
//  OptionALS
//
//  Created by Vikram Ponnuswamy on 23/04/2023.
//

import SwiftUI

struct ContentView: View {
    
    @State var arrayOfStrings:[String]!
    
    
    var body: some View {
        
        VStack {
            
            HStack {
                Button {
                    arrayOfStrings = nil
                
                } label: {
                    Text("Set Nil")
                }
                .padding(.horizontal)
                .background(.black)
                .foregroundColor(.white)
                .font(.title)
                Button {
                   
                    arrayOfStrings  = [String]()
                    arrayOfStrings?.append("Mango")
                    arrayOfStrings?.append("Apple")
                } label: {
                    Text("Add Fruits")
                }
                .padding(.horizontal)
                .background(.black)
                .foregroundColor(.white)
                .font(.title)
            }
           
            
            if arrayOfStrings == nil {
                Text("Value is Nil")
            }
            else {
                List(arrayOfStrings!, id: \.self) { item in
                    Text(item)
                }

           
                
            }
          
        }
        
        
        
        
        
        
        
    }
    
    
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
    
}
