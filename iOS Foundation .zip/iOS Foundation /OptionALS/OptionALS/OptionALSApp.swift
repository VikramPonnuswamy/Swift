//
//  OptionALSApp.swift
//  OptionALS
//
//  Created by Vikram Ponnuswamy on 23/04/2023.
//

import SwiftUI

@main
struct OptionALSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
