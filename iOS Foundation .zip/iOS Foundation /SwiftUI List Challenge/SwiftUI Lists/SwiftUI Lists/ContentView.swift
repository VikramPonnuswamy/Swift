//
//  ContentView.swift
//  SwiftUI Lists
//
//  Created by Vikram Ponnuswamy on 14/04/2023.
//

import SwiftUI

struct ContentView: View {
    
    var fruits = ["Mango", "Orange", "Apple", "Banana", "Guava"]
    
    @State var addItem = [String]()
    
    var body: some View {
        VStack{
            List (addItem, id: \.self){ arrayElement in
                
                Text(arrayElement)
                
            }
            Button("List Generator") {
                listGen()
                
                
                
            }
            
        }
        
        
        func listGen() {
            var randIndex = Int.random(in: 0...(fruits.count - 1))
            var item = fruits[randIndex]
            
            addItem.append(item)
            
            print(item)
            
        }
    }
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}
