//
//  SwiftUI_ListsApp.swift
//  SwiftUI Lists
//
//  Created by Vikram Ponnuswamy on 14/04/2023.
//

import SwiftUI

@main
struct SwiftUI_ListsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
