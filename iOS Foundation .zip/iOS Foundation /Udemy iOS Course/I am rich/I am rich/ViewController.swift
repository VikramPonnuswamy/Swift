//
//  ViewController.swift
//  I am rich
//
//  Created by Vikram Ponnuswamy on 08/05/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

